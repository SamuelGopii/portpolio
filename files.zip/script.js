
// writing text
const sentences = [
    "I'm SamuelGopi.|",
    "I'm a Designer.|",
    "I'm a Freelancer.|",
    "I'm a Backend Developer.|"
  ];

  const textContainer = document.getElementById('text-container');
    let sentenceIndex = 0;
    let charIndex = 0;

    function type() {
      if (sentenceIndex < sentences.length) {
        if (charIndex <= sentences[sentenceIndex].length) {
          textContainer.textContent = sentences[sentenceIndex].substring(0, charIndex);
          charIndex++;
          setTimeout(type, 100); // Adjust the typing speed here (in milliseconds)
        } else {
          sentenceIndex++;
          charIndex = 0;
          setTimeout(type, 1000); // Delay between sentences (in milliseconds)
        }
      }
    }

    // Start the typing animation
    type();

    const loading = document.querySelector('.loading');

    window.addEventListener('load', ()=>{
        loading.style.display = 'none';
    })


const All = document.getElementById('all');
const Design = document.getElementById('design');
const Brand = document.getElementById('brand');
const Photos = document.getElementById('photos');

const portfolio_tab_section = document.querySelector('.portfolio-tab-section');

const Portfolio_tab_id1 = document.getElementById('portfolio-tab-id1');
const Portfolio_tab_id2 = document.getElementById('portfolio-tab-id2');
const Portfolio_tab_id3 = document.getElementById('portfolio-tab-id3');
const Portfolio_tab_id4 = document.getElementById('portfolio-tab-id4');


portfolio_tab_section.addEventListener('click', (e)=>{
  if(e.target === All){
    e.preventDefault();
    Portfolio_tab_id1.classList.add('tab-positon-show')
    Portfolio_tab_id2.classList.remove('tab-positon-show')
    Portfolio_tab_id3.classList.remove('tab-positon-show')
    Portfolio_tab_id4.classList.remove('tab-positon-show')
    All.style.color = 'green';
    Design.style.color = 'grey';
    Brand.style.color = 'grey';
    Photos.style.color = 'grey';
  }else if(e.target === Design){
    e.preventDefault();
    Portfolio_tab_id1.classList.remove('tab-positon-show')
    Portfolio_tab_id2.classList.add('tab-positon-show')
    Portfolio_tab_id3.classList.remove('tab-positon-show')
    Portfolio_tab_id4.classList.remove('tab-positon-show')
    Design.style.color = 'green';
    All.style.color = 'grey';
    Brand.style.color = 'grey';
    Photos.style.color = 'grey';
  }else if(e.target === Brand){
    e.preventDefault();
    Portfolio_tab_id1.classList.remove('tab-positon-show')
    Portfolio_tab_id2.classList.remove('tab-positon-show')
    Portfolio_tab_id3.classList.add('tab-positon-show')
    Portfolio_tab_id4.classList.remove('tab-positon-show')
    All.style.color = 'grey';
    Design.style.color = 'grey';
    Brand.style.color = 'green';
    Photos.style.color = 'grey';
  }else if(e.target === Photos){
    e.preventDefault();
    Portfolio_tab_id1.classList.remove('tab-positon-show')
    Portfolio_tab_id2.classList.remove('tab-positon-show')
    Portfolio_tab_id3.classList.remove('tab-positon-show')
    Portfolio_tab_id4.classList.add('tab-positon-show')
    All.style.color = 'grey';
    Design.style.color = 'grey';
    Brand.style.color = 'grey';
    Photos.style.color = 'green';
  }
})


const all1_tab1_inner_all_tab1 = document.querySelector('.all1-tab1 .inner-all-tab1');
const all1_tab1_inner_all_tab1_h4 = document.querySelector('.all1-tab1 .inner-all-tab1 h4');
const all1_tab1_inner_all_tab1_p = document.querySelector('.all1-tab1 .inner-all-tab1 p');
const tabcanvas1 = document.querySelector('.all1-tab1 .inner-all-tab1 .canvas');

all1_tab1_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all1_tab1_inner_all_tab1_h4.style.display = 'block';
  all1_tab1_inner_all_tab1_p.style.display = 'block';
  tabcanvas1.style.display = 'block';

})
all1_tab1_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all1_tab1_inner_all_tab1_h4.style.display = 'none';
  all1_tab1_inner_all_tab1_p.style.display = 'none';
  tabcanvas1.style.display = 'none';
})

const all1_tab1_inner_all_tab2 = document.querySelector('.all1-tab1 .inner-all-tab2');
const all1_tab1_inner_all_tab2_h4 = document.querySelector('.all1-tab1 .inner-all-tab2 h4');
const all1_tab1_inner_all_tab2_p = document.querySelector('.all1-tab1 .inner-all-tab2 p');
const tabcanvas2 = document.querySelector('.all1-tab1 .inner-all-tab2 .canvas');

all1_tab1_inner_all_tab2.addEventListener('mouseenter', ()=>{
  all1_tab1_inner_all_tab2_h4.style.display = 'block';
  all1_tab1_inner_all_tab2_p.style.display = 'block';
  tabcanvas2.style.display = 'block';

})
all1_tab1_inner_all_tab2.addEventListener('mouseleave', ()=>{
  all1_tab1_inner_all_tab2_h4.style.display = 'none';
  all1_tab1_inner_all_tab2_p.style.display = 'none';
  tabcanvas2.style.display = 'none';
})

const all1_tab2_inner_all_tab1 = document.querySelector('.all1-tab2 .inner-all-tab1');
const all1_tab2_inner_all_tab1_h4 = document.querySelector('.all1-tab2 .inner-all-tab1 h4');
const all1_tab2_inner_all_tab1_p = document.querySelector('.all1-tab2 .inner-all-tab1 p');
const tabcanvas3 = document.querySelector('.all1-tab2 .inner-all-tab1 .canvas');

all1_tab2_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all1_tab2_inner_all_tab1_h4.style.display = 'block';
  all1_tab2_inner_all_tab1_p.style.display = 'block';
  tabcanvas3.style.display = 'block';

})
all1_tab2_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all1_tab2_inner_all_tab1_h4.style.display = 'none';
  all1_tab2_inner_all_tab1_p.style.display = 'none';
  tabcanvas3.style.display = 'none';
})

const all1_tab2_inner_all_tab2 = document.querySelector('.all1-tab2 .inner-all-tab2');
const all1_tab2_inner_all_tab2_h4 = document.querySelector('.all1-tab2 .inner-all-tab2 h4');
const all1_tab2_inner_all_tab2_p = document.querySelector('.all1-tab2 .inner-all-tab2 p');
const tabcanvas4 = document.querySelector('.all1-tab2 .inner-all-tab2 .canvas');

all1_tab2_inner_all_tab2.addEventListener('mouseenter', ()=>{
  all1_tab2_inner_all_tab2_h4.style.display = 'block';
  all1_tab2_inner_all_tab2_p.style.display = 'block';
  tabcanvas4.style.display = 'block';

})
all1_tab2_inner_all_tab2.addEventListener('mouseleave', ()=>{
  all1_tab2_inner_all_tab2_h4.style.display = 'none';
  all1_tab2_inner_all_tab2_p.style.display = 'none';
  tabcanvas4.style.display = 'none';
})

const all1_tab3_inner_all_tab1 = document.querySelector('.all1-tab3 .inner-all-tab1');
const all1_tab3_inner_all_tab1_h4 = document.querySelector('.all1-tab3 .inner-all-tab1 h4');
const all1_tab3_inner_all_tab1_p = document.querySelector('.all1-tab3 .inner-all-tab1 p');
const tabcanvas5 = document.querySelector('.all1-tab3 .inner-all-tab1 .canvas');

all1_tab3_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all1_tab3_inner_all_tab1_h4.style.display = 'block';
  all1_tab3_inner_all_tab1_p.style.display = 'block';
  tabcanvas5.style.display = 'block';

})
all1_tab3_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all1_tab3_inner_all_tab1_h4.style.display = 'none';
  all1_tab3_inner_all_tab1_p.style.display = 'none';
  tabcanvas5.style.display = 'none';
})

const all1_tab3_inner_all_tab2 = document.querySelector('.all1-tab3 .inner-all-tab2');
const all1_tab3_inner_all_tab2_h4 = document.querySelector('.all1-tab3 .inner-all-tab2 h4');
const all1_tab3_inner_all_tab2_p = document.querySelector('.all1-tab3 .inner-all-tab2 p');
const tabcanvas6 = document.querySelector('.all1-tab3 .inner-all-tab2 .canvas');

all1_tab3_inner_all_tab2.addEventListener('mouseenter', ()=>{
  all1_tab3_inner_all_tab2_h4.style.display = 'block';
  all1_tab3_inner_all_tab2_p.style.display = 'block';
  tabcanvas6.style.display = 'block';

})
all1_tab3_inner_all_tab2.addEventListener('mouseleave', ()=>{
  all1_tab3_inner_all_tab2_h4.style.display = 'none';
  all1_tab3_inner_all_tab2_p.style.display = 'none';
  tabcanvas6.style.display = 'none';
})

const all1_tab3_inner_all_tab3 = document.querySelector('.all1-tab3 .inner-all-tab3');
const all1_tab3_inner_all_tab3_h4 = document.querySelector('.all1-tab3 .inner-all-tab3 h4');
const all1_tab3_inner_all_tab3_p = document.querySelector('.all1-tab3 .inner-all-tab3 p');
const tabcanvas7 = document.querySelector('.all1-tab3 .inner-all-tab3 .canvas');

all1_tab3_inner_all_tab3.addEventListener('mouseenter', ()=>{
  all1_tab3_inner_all_tab3_h4.style.display = 'block';
  all1_tab3_inner_all_tab3_p.style.display = 'block';
  tabcanvas7.style.display = 'block';

})
all1_tab3_inner_all_tab3.addEventListener('mouseleave', ()=>{
  all1_tab3_inner_all_tab3_h4.style.display = 'none';
  all1_tab3_inner_all_tab3_p.style.display = 'none';
  tabcanvas7.style.display = 'none';
})

const all2_tab1_inner_all_tab1 = document.querySelector('.all2-tab1 .inner-all-tab1');
const all2_tab1_inner_all_tab1_h4 = document.querySelector('.all2-tab1 .inner-all-tab1 h4');
const all2_tab1_inner_all_tab1_p = document.querySelector('.all2-tab1 .inner-all-tab1 p');
const tabcanvas8 = document.querySelector('.all2-tab1 .inner-all-tab1 .canvas');

all2_tab1_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all2_tab1_inner_all_tab1_h4.style.display = 'block';
  all2_tab1_inner_all_tab1_p.style.display = 'block';
  tabcanvas8.style.display = 'block';

})
all2_tab1_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all2_tab1_inner_all_tab1_h4.style.display = 'none';
  all2_tab1_inner_all_tab1_p.style.display = 'none';
  tabcanvas8.style.display = 'none';
})

const all2_tab2_inner_all_tab2 = document.querySelector('.all2-tab2 .inner-all-tab1');
const all2_tab2_inner_all_tab2_h4 = document.querySelector('.all2-tab2 .inner-all-tab1 h4');
const all2_tab2_inner_all_tab2_p = document.querySelector('.all2-tab2 .inner-all-tab1 p');
const tabcanvas9 = document.querySelector('.all2-tab2 .inner-all-tab1 .canvas');

all2_tab2_inner_all_tab2.addEventListener('mouseenter', ()=>{
  all2_tab2_inner_all_tab2_h4.style.display = 'block';
  all2_tab2_inner_all_tab2_p.style.display = 'block';
  tabcanvas9.style.display = 'block';

})
all2_tab2_inner_all_tab2.addEventListener('mouseleave', ()=>{
  all2_tab2_inner_all_tab2_h4.style.display = 'none';
  all2_tab2_inner_all_tab2_p.style.display = 'none';
  tabcanvas9.style.display = 'none';
})

const all2_tab3_inner_all_tab1 = document.querySelector('.all2-tab3 .inner-all-tab1');
const all2_tab3_inner_all_tab1_h4 = document.querySelector('.all2-tab3 .inner-all-tab1 h4');
const all2_tab3_inner_all_tab1_p = document.querySelector('.all2-tab3 .inner-all-tab1 p');
const tabcanvas10 = document.querySelector('.all2-tab3 .inner-all-tab1 .canvas');

all2_tab3_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all2_tab3_inner_all_tab1_h4.style.display = 'block';
  all2_tab3_inner_all_tab1_p.style.display = 'block';
  tabcanvas10.style.display = 'block';

})
all2_tab3_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all2_tab3_inner_all_tab1_h4.style.display = 'none';
  all2_tab3_inner_all_tab1_p.style.display = 'none';
  tabcanvas10.style.display = 'none';
})

const all3_tab1_inner_all_tab1 = document.querySelector('.all3-tab1 .inner-all-tab1');
const all3_tab1_inner_all_tab1_h4 = document.querySelector('.all3-tab1 .inner-all-tab1 h4');
const all3_tab1_inner_all_tab1_p = document.querySelector('.all3-tab1 .inner-all-tab1 p');
const tabcanvas11 = document.querySelector('.all3-tab1 .inner-all-tab1 .canvas');

all3_tab1_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all3_tab1_inner_all_tab1_h4.style.display = 'block';
  all3_tab1_inner_all_tab1_p.style.display = 'block';
  tabcanvas11.style.display = 'block';

})
all3_tab1_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all3_tab1_inner_all_tab1_h4.style.display = 'none';
  all3_tab1_inner_all_tab1_p.style.display = 'none';
  tabcanvas11.style.display = 'none';
})

const all3_tab2_inner_all_tab1 = document.querySelector('.all3-tab2 .inner-all-tab1');
const all3_tab2_inner_all_tab1_h4 = document.querySelector('.all3-tab2 .inner-all-tab1 h4');
const all3_tab2_inner_all_tab1_p = document.querySelector('.all3-tab2 .inner-all-tab1 p');
const tabcanvas12 = document.querySelector('.all3-tab2 .inner-all-tab1 .canvas');

all3_tab2_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all3_tab2_inner_all_tab1_h4.style.display = 'block';
  all3_tab2_inner_all_tab1_p.style.display = 'block';
  tabcanvas12.style.display = 'block';

})
all3_tab2_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all3_tab2_inner_all_tab1_h4.style.display = 'none';
  all3_tab2_inner_all_tab1_p.style.display = 'none';
  tabcanvas12.style.display = 'none';
})

const all3_tab3_inner_all_tab1 = document.querySelector('.all3-tab3 .inner-all-tab1');
const all3_tab3_inner_all_tab1_h4 = document.querySelector('.all3-tab3 .inner-all-tab1 h4');
const all3_tab3_inner_all_tab1_p = document.querySelector('.all3-tab3 .inner-all-tab1 p');
const tabcanvas13 = document.querySelector('.all3-tab3 .inner-all-tab1 .canvas');

all3_tab3_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all3_tab3_inner_all_tab1_h4.style.display = 'block';
  all3_tab3_inner_all_tab1_p.style.display = 'block';
  tabcanvas13.style.display = 'block';

})
all3_tab3_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all3_tab3_inner_all_tab1_h4.style.display = 'none';
  all3_tab3_inner_all_tab1_p.style.display = 'none';
  tabcanvas13.style.display = 'none';
})

const all4_tab1_inner_all_tab1 = document.querySelector('.all4-tab1 .inner-all-tab1');
const all4_tab1_inner_all_tab1_h4 = document.querySelector('.all4-tab1 .inner-all-tab1 h4');
const all4_tab1_inner_all_tab1_p = document.querySelector('.all4-tab1 .inner-all-tab1 p');
const tabcanvas14 = document.querySelector('.all4-tab1 .inner-all-tab1 .canvas');

all4_tab1_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all4_tab1_inner_all_tab1_h4.style.display = 'block';
  all4_tab1_inner_all_tab1_p.style.display = 'block';
  tabcanvas14.style.display = 'block';

})
all4_tab1_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all4_tab1_inner_all_tab1_h4.style.display = 'none';
  all4_tab1_inner_all_tab1_p.style.display = 'none';
  tabcanvas14.style.display = 'none';
})

const all4_tab2_inner_all_tab1 = document.querySelector('.all4-tab2 .inner-all-tab1');
const all4_tab2_inner_all_tab1_h4 = document.querySelector('.all4-tab2 .inner-all-tab1 h4');
const all4_tab2_inner_all_tab1_p = document.querySelector('.all4-tab2 .inner-all-tab1 p');
const tabcanvas15 = document.querySelector('.all4-tab2 .inner-all-tab1 .canvas');

all4_tab2_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all4_tab2_inner_all_tab1_h4.style.display = 'block';
  all4_tab2_inner_all_tab1_p.style.display = 'block';
  tabcanvas15.style.display = 'block';

})
all4_tab2_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all4_tab2_inner_all_tab1_h4.style.display = 'none';
  all4_tab2_inner_all_tab1_p.style.display = 'none';
  tabcanvas15.style.display = 'none';
})

const all4_tab3_inner_all_tab1 = document.querySelector('.all4-tab3 .inner-all-tab1');
const all4_tab3_inner_all_tab1_h4 = document.querySelector('.all4-tab3 .inner-all-tab1 h4');
const all4_tab3_inner_all_tab1_p = document.querySelector('.all4-tab3 .inner-all-tab1 p');
const tabcanvas16 = document.querySelector('.all4-tab3 .inner-all-tab1 .canvas');

all4_tab3_inner_all_tab1.addEventListener('mouseenter', ()=>{
  all4_tab3_inner_all_tab1_h4.style.display = 'block';
  all4_tab3_inner_all_tab1_p.style.display = 'block';
  tabcanvas16.style.display = 'block';

})
all4_tab3_inner_all_tab1.addEventListener('mouseleave', ()=>{
  all4_tab3_inner_all_tab1_h4.style.display = 'none';
  all4_tab3_inner_all_tab1_p.style.display = 'none';
  tabcanvas16.style.display = 'none';
})




// client testimonial section
var swiper = new Swiper(".mySwiper", {
  slidesPerView: 2,
  spaceBetween: 30,
  // pagination: {
  //   el: ".swiper-pagination",
  //   clickable: true,
  // },
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
});

// scroll button
const scroll_Btn = document.querySelector('.ri-arrow-up-circle-fill');

window.addEventListener('scroll', ()=>{
   if(window.scrollY>119.33333587646484){
    scroll_Btn.style.display = 'block';
   }else{
    scroll_Btn.style.display = 'none';
   }
})
scroll_Btn.addEventListener('click', ()=>{
  window.scrollTo({top:0, behavior:'smooth'});
})

const Home_Btn = document.querySelector('.logo h1');

Home_Btn.addEventListener('click', ()=>{
  window.location.assign('http://127.0.0.1:5500/index.html');
})
Home_Btn.addEventListener('mouseover', ()=>{
  Home_Btn.style.cursor = 'pointer';
})

// drop header functionality
const drop_header = document.querySelector('.drop-header');

window.addEventListener('scroll', ()=>{
  if(window.scrollY>157){
    drop_header.style.height = '15%';
  }else{
    drop_header.style.height = '0%';
  }
})

const drop_header_home_btn = document.querySelector('.drop-header .drop-logo h1');
drop_header_home_btn.onclick = ()=>{
  window.location.assign('http://127.0.0.1:5500/index.html');
}



// portfolio tabs inner pages functionality
const tab1 = document.querySelector('#tab1');
tab1.addEventListener('click', (e)=>{
   e.preventDefault();
   window.location.assign('http://127.0.0.1:5500/Portfolio_Pages/schoolpage.html')
})


